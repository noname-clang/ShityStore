const BaseUrl = 'https://fakestoreapi.com/'

async function SendGetToAPI(endpoint)
{
    const request = await fetch(BaseUrl+endpoint)
    return await request.json()
}

async function ShowProducts(){
    const data = await SendGetToAPI("products")
    console.log(data)
    const charactercontainer = document.getElementById("products-container")
    data.map((datareccebida,index) =>{
        const DivCharacter = document.createElement('div')
        DivCharacter.innerHTML = `
        <img src="${datareccebida.image}" alt="imagemdopersonagem" >
        <article>
        <h3>${datareccebida.title} </h3>
        <span class="Description" id="description">Description :</span>
        <p id="detalhe-desc">${datareccebida.description}</p>
        </article>
        `
        DivCharacter.classList.add(`products-box${index}`)
        charactercontainer.appendChild(DivCharacter)
    })
    
}
document.addEventListener('DOMContentLoaded',ShowProducts())